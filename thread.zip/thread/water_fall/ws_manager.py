# ws_manager.py

import socket
import threading
import json
from thread.greeksoft_1 import GreekAPI

HOST = "127.0.0.1"
PORT = 5000

clients = {}

api = GreekAPI(
    user="G911",
    s_pwd="greek@123",
    pwd="g@4444444444",
    procli="2",
    ac_no="",
    is_secure=False,
    is_base_64=True,
    rest_ip="dev.greeksoft.in",
    rest_port="3333"
)

api.start_apollo(['101002885'], "allresp")
# time.sleep(2)

subscribed_tokens = set()


def handle_client(conn):
    print("New client connected")

    buffer = ""

    while True:
        try:
            chunk = conn.recv(4096).decode()
            if not chunk:
                break

            buffer += chunk

            while "\n" in buffer:
                line, buffer = buffer.split("\n", 1)

                if not line.strip():
                    continue

                msg = json.loads(line)

                strategy_name = msg["strategy"]
                tokens = msg["tokens"]

                print("Register:", strategy_name, tokens)

                clients[strategy_name] = {
                    "conn": conn,
                    "tokens": set(str(t) for t in tokens)
                }

                # Subscribe tokens only once globally
                for t in tokens:
                    t = str(t)
                    if t not in subscribed_tokens:
                        subscribed_tokens.add(t)
                        api.subscribe_token([t])
                        print("Subscribed:", t)

        except Exception as e:
            print("Error:", e)
            break



# def market_data_router():
#     print("Router started")
#
#     for data in api.data_stream():
#
#         if isinstance(data, tuple):
#             token = str(data[0])
#         else:
#             token = str(data.get("symbol"))
#
#         for strategy, info in list(clients.items()):
#             if token in info["tokens"]:
#                 try:
#                     msg = json.dumps(data) + "\n"
#                     info["conn"].sendall(msg.encode())
#                 except:
#                     print("Client disconnected:", strategy)
#                     del clients[strategy]

def market_data_router():
    print("🚀 Router started")

    for data in api.data_stream():
        print("📡 WS Tick Received:", data)

        if isinstance(data, tuple):
            token = str(data[0])
        else:
            token = str(data.get("symbol"))

        print("🎯 Incoming Token:", token)

        for strategy, info in clients.items():
            print("Checking strategy:", strategy)

            if token in info["tokens"]:
                print("✅ Sending to:", strategy)
                info["conn"].sendall((json.dumps(data) + "\n").encode())





def start_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((HOST, PORT))
    server.listen()

    print("WebSocket Manager Running...")

    threading.Thread(target=market_data_router, daemon=True).start()

    while True:
        conn, addr = server.accept()
        threading.Thread(target=handle_client, args=(conn,), daemon=True).start()


if __name__ == "__main__":
    start_server()
