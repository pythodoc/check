import socket
import json

HOST = "127.0.0.1"
PORT = 5000

strategy_name = "strategy1"
tokens = ["101000025"]

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((HOST, PORT))

# Send subscription
msg = json.dumps({
    "strategy": strategy_name,
    "tokens": tokens
}) + "\n"

client.sendall(msg.encode())

print("Strategy1 Connected")

buffer = ""

while True:
    chunk = client.recv(4096).decode()
    print("RAW CHUNK:", chunk)
    if not chunk:
        break

    buffer += chunk

    while "\n" in buffer:
        line, buffer = buffer.split("\n", 1)
        tick = json.loads(line)
        print("Strategy1 Tick:", tick)
